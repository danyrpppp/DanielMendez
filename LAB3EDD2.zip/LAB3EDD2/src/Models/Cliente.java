// Cliente.java
package Models;

import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Cliente {

    private static String HOST_WORKER = "localhost"; // Dirección predeterminada
    private static final int PUERTO_WORKER0 = 49152;
    private static final int PUERTO_CLIENTE = 49154;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            configurarHostWorker(scanner);

            while (true) {
                System.out.println("------------------Menu-------------------");

                // Paso 1: Seleccionar cómo crear el vector
                System.out.println("Seleccione como desea crear el vector o la opcion que prefiera:");
                System.out.println("1. Numeros aleatorios");
                System.out.println("2. Desde archivo TXT");
                System.out.println("3. Salir");
                System.out.println("-------------------------------");
                System.out.print("Escriba unicamente el numero de su eleccion: ");
                int opcionEntrada = scanner.nextInt();

                int[] vector = null;

                if (opcionEntrada == 1) {
                    System.out.println("Ingrese la longitud del vector (Ingrese unicamente un valor entero):");
                    int n = scanner.nextInt();
                    vector = generarVectorAleatorio(n);
                } else if (opcionEntrada == 2) {
                    scanner.nextLine();
                    System.out.println("Ingrese la ruta del archivo TXT (Ej: C:\\Users\\subje\\Desktop\\Ejemplo.txt): ");
                    String rutaArchivo = scanner.nextLine();
                    vector = leerVectorDesdeArchivo(rutaArchivo);
                } else if (opcionEntrada == 3) {
                    break;
                }

                // Paso 2: Seleccionar el método de ordenamiento
                System.out.println("\nSeleccione el metodo de ordenamiento:");
                System.out.println("1. MergeSort");
                System.out.println("2. QuickSort");
                System.out.println("3. HeapSort");
                System.out.print("Escriba unicamente el numero de su eleccion: ");
                int metodoOrdenamiento = scanner.nextInt();

                // Paso 3: Establecer el tiempo límite
                System.out.println("\nIngrese el tiempo limite en segundos (Ingrese unicamente un valor entero):");
                int tiempoLimite = scanner.nextInt();

                // Mostrar el vector original
                System.out.println("\nVector original: " + Arrays.toString(vector));

                // Paso 4: Enviar datos al Worker0 y medir el tiempo de espera
                long tiempoInicio = System.currentTimeMillis(); // Registrar inicio
                try (Socket socket = new Socket(HOST_WORKER, PUERTO_WORKER0)) {
                    System.out.println("\nConectando con Worker0...");
                    ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
                    salida.writeObject(vector);
                    salida.writeInt(metodoOrdenamiento);
                    salida.writeInt(tiempoLimite);
                    salida.flush();
                    System.out.println("Datos enviados con exito");

                    // Esperar respuesta desde cualquier worker
                    int[] vectorOrdenado = esperarRespuesta();
                    long tiempoFin = System.currentTimeMillis(); // Registrar fin

                    // Calcular tiempo total
                    double tiempoTotal = (tiempoFin - tiempoInicio) / 1000.0;

                    // Mostrar resultados
                    System.out.println("Tiempo total de espera: " + tiempoTotal + " segundos");
                    System.out.println("----------------------------------");
                    System.out.println("Vector ordenado: " + Arrays.toString(vectorOrdenado));
                }
            }

        } catch (Exception e) {
            System.err.println("Error en el cliente: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void configurarHostWorker(Scanner scanner) {
        System.out.println("Ingrese la direccion IP del host para los workers (o presione Enter para usar localhost): ");
        String ip = scanner.nextLine();
        if (!ip.isBlank()) {
            HOST_WORKER = ip;
        }
        System.out.println("Usando la direccion IP: " + HOST_WORKER);
    }

    private static int[] generarVectorAleatorio(int n) {
        int[] vector = new int[n];
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            vector[i] = random.nextInt(1000);
        }
        return vector;
    }

    private static int[] leerVectorDesdeArchivo(String rutaArchivo) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo));
        String linea;
        StringBuilder contenido = new StringBuilder();

        while ((linea = reader.readLine()) != null) {
            contenido.append(linea).append(",");
        }
        reader.close();

        String[] numerosStr = contenido.toString().split(",");
        int[] vector = new int[numerosStr.length];

        for (int i = 0; i < numerosStr.length; i++) {
            vector[i] = Integer.parseInt(numerosStr[i].trim());
        }

        return vector;
    }

    private static int[] esperarRespuesta() throws IOException, ClassNotFoundException {
        try (ServerSocket serverSocket = new ServerSocket(PUERTO_CLIENTE)) {
            System.out.println("Esperando vector ordenado...");
            try (Socket workerSocket = serverSocket.accept(); ObjectInputStream entrada = new ObjectInputStream(workerSocket.getInputStream())) {
                return (int[]) entrada.readObject();
            }
        }
    }
}
