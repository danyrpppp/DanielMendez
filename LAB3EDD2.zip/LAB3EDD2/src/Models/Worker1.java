// Worker1.java
package Models;

import java.io.*;
import java.net.*;

public class Worker1 {

    private static final int PUERTO = 49153;
    private static final int PUERTO_WORKER0 = 49152;
    private static final int PUERTO_CLIENTE = 49154;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Worker1 iniciado en puerto " + PUERTO);

            while (true) {
                try (Socket workerSocket = serverSocket.accept()) {
                    manejarCliente(workerSocket);
                } catch (Exception e) {
                    System.err.println("[Worker1] Error manejando conexion: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("[Worker1] Error iniciando servidor: " + e.getMessage());
        }
    }

    private static void manejarCliente(Socket socket) throws IOException, ClassNotFoundException {
        ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream());

        int[] vector = (int[]) entrada.readObject();
        int metodoOrdenamiento = entrada.readInt();
        int tiempoLimite = entrada.readInt();

        System.out.println("[Worker1] Iniciando ordenamiento...");
        procesarOrdenamiento(vector, metodoOrdenamiento, tiempoLimite, PUERTO_WORKER0);
    }

    private static void procesarOrdenamiento(int[] vector, int metodoOrdenamiento, int tiempoLimite, int puertoDestino) {
        Ordenamientos ordenador = new Ordenamientos();
        Thread hiloOrdenamiento = new Thread(() -> {
            try {
                switch (metodoOrdenamiento) {
                    case 1 ->
                        ordenador.mergeSort(vector, 0, vector.length - 1);
                    case 2 ->
                        ordenador.quickSort(vector, 0, vector.length - 1);
                    case 3 ->
                        ordenador.heapSort(vector);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        hiloOrdenamiento.start();

        try {
            hiloOrdenamiento.join(tiempoLimite * 1000L);
            if (hiloOrdenamiento.isAlive()) {
                System.out.println("[Worker1] Tiempo agotado. Reenviando a Worker0...");
                System.out.println("-----------------------");
                hiloOrdenamiento.interrupt();
                reenviarAWorker(vector, metodoOrdenamiento, tiempoLimite, puertoDestino);
            } else {
                System.out.println("[Worker1] Ordenamiento completado. Enviando al cliente...");
                System.out.println("-----------------------");
                enviarAlCliente(vector);
            }
        } catch (InterruptedException e) {
            System.err.println("[Worker1] Error durante la ejecución: " + e.getMessage());
        }
    }

    private static void reenviarAWorker(int[] vector, int metodoOrdenamiento, int tiempoLimite, int puertoDestino) {
        try (Socket socket = new Socket(InetAddress.getLocalHost().getHostAddress(), puertoDestino); ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream())) {
            salida.writeObject(vector);
            salida.writeInt(metodoOrdenamiento);
            salida.writeInt(tiempoLimite);
            salida.flush();
        } catch (IOException e) {
            System.err.println("[Worker1] Error al reenviar datos: " + e.getMessage());
        }
    }

    private static void enviarAlCliente(int[] vector) {
        try (Socket clienteSocket = new Socket(InetAddress.getLocalHost().getHostAddress(), PUERTO_CLIENTE); ObjectOutputStream salida = new ObjectOutputStream(clienteSocket.getOutputStream())) {
            salida.writeObject(vector);
            salida.flush();
        } catch (IOException e) {
            System.err.println("[Worker1] Error enviando al cliente: " + e.getMessage());
        }
    }
}
